library(testthat)
library(BRCindicators)

test_check("BRCindicators")