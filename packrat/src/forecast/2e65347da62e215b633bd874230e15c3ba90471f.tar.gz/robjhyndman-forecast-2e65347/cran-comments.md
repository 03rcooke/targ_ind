## Test environments
* ubuntu 20.04 (local): R 4.1.2
* macOS (on GitHub Actions): release
* windows (on GitHub Actions): release
* ubuntu 20.04 (on GitHub Actions): devel, release, oldrel
* win-builder: devel, release, oldrelease

## R CMD check results

0 errors | 0 warnings | 0 notes

## revdep checks

All reverse dependencies have been checked and no new errors with current CRAN versions.
